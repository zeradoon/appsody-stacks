package com.skcc.template.rest.sample_domain;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RestSampleDomainApplicationTests {

	@Test
	void contextLoads() {
	}

}
