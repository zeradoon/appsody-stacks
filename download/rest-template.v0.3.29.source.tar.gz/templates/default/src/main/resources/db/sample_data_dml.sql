INSERT INTO SAMPLE_DOMAIN (id, sample_data1, sample_data2) VALUES
  ('1', 'sample_data11', 'sample_data21'),
  ('2', 'sample_data12', 'sample_data22');